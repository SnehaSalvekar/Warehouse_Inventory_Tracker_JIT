package com.java.assign;

public class Product
{
 private String pid;
 private String pname;
 private int pquantity;
 private int pthreshold;
 
public String getPid() 
{
	return pid;
}
public void setPid(String pid) 
{
	this.pid = pid;
}
public String getPname()
{
	return pname;
}
public void setPname(String pname) 
{
	this.pname = pname;
}
public int getPquantity() 
{
	return pquantity;
}
public void setPquantity(int pquantity) 
{
	this.pquantity = pquantity;
}
public int getPthreshold() 
{
	return pthreshold;
}
public void setPthreshold(int pthreshold)
{
	this.pthreshold = pthreshold;
}
 
 
 
}
