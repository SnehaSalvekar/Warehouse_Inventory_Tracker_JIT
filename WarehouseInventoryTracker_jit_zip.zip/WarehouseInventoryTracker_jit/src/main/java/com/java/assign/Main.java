package com.java.assign;
import java.util.*;
public class Main {

	public static void main(String[] args)
	{
		Product pd=new Product();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter id, name, quantity, Threshold of Product : ");
        String id,name;
        int qnt,threshold;
        id=s.nextLine();
        name=s.nextLine();
        qnt=s.nextInt();
        threshold=s.nextInt(); 
        
        pd.setPid(id);
        pd.setPname(name);
        pd.setPquantity(qnt);
        pd.setPthreshold(threshold);
	}

}
